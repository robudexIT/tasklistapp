const AWS = require('aws-sdk')
exports.handler = (event, context, cb) => {
    const dbTable = process.env.DB_TABLE
    const documentClient = new AWS.DynamoDB.DocumentClient()
    const params = {
        TableName: dbTable,
        Select: COUNT
    }

    documentClient.scan(params, (error, data) => {
        if(error){
            console.log(error)
            cb(null, {message:'Fetching Data is unsuccessfull', error, getList:false})
            return
        }
        console.log(data)
        cb(null, {message: 'Fetching Data is Successfull', data: data.Items, getList:true})
    })


}